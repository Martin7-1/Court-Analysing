package com.nju.edu.court;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourtApplicationTests {

    @Test
    void contextLoads() {
    }

}
