var textField = $('#textField')
console.log(textField.val())
var textField2 = document.getElementById('textField')
console.log(textField2)
