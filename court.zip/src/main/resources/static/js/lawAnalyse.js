
var ar = document.getElementsByid("analysedResult");
var btns = ar.getElementsByTagName('input')
console.log(btns)